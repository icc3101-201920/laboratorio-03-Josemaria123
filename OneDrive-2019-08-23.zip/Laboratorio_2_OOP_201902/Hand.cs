﻿using Laboratorio_2_OOP_201902.Card;
using System;
using System.Collections.Generic;
using System.Text;

namespace Laboratorio_2_OOP_201902
{
    public class Hand : Deck
    {

        public Hand()
        {
            
        }

        
    }
}
